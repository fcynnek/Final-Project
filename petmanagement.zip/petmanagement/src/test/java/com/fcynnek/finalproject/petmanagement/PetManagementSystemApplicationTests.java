package com.fcynnek.finalproject.petmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
